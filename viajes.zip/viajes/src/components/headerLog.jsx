import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';


    


function HeaderLog (){
    
    return(
        <div className="header2">
            
                <Navbar bg="light" expand="lg">
                    <Container>
                        <Navbar.Brand >V O L F L Y</Navbar.Brand>
                        <Navbar.Toggle aria-controls="basic-navbar-nav" />
                        <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="options">
                            <NavDropdown title="☰" id="basic-nav-dropdown">
                            <NavDropdown.Item >Purchased</NavDropdown.Item>
                            <NavDropdown.Item>Search history</NavDropdown.Item>
                            <NavDropdown.Item >Account</NavDropdown.Item> 
                            <NavDropdown.Divider/>
                            <NavDropdown.Item>Log Out </NavDropdown.Item> 
                            </NavDropdown>
                        </Nav>
                        </Navbar.Collapse>
                    </Container>
                </Navbar>
            </div>
    );
}

export default HeaderLog

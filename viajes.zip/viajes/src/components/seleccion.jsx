import React from "react";
import { logged } from "./header";
import App2 from "./login/App2";
import Main from "./main";



function Selection() {
    console.log(logged);
    if (logged===true) {
        return(
            <div>
                <App2/>
            </div>
        )
    }else{
        return(
            <div>
                <Main/>
            </div>
        )
    }
}

export default Selection
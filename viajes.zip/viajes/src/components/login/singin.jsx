import React from "react";
import { useState } from "react";
import 'regenerator-runtime/runtime';
import axios from 'axios';
import BG from "../videos/back.mp4"

function SignIn(props){
    var[registerInfo, setRegisterInfo] =useState({ 
        password: "",
        fname: "",
        lname: "",
        email:"",
        adm:false,
        regis:false,
    })
    var[errorMSG, setErrorMSG]= useState("Ocurrio un error de algo");

    function handleUpdate(e) {
        const {value, name} = e.target;
        setRegisterInfo((preValue) =>{
            if(name=== "Password"){
                return{
                    ...preValue,
                    password: value, };
            }else if(name=== "LastName"){
                return{
                    ...preValue,
                    lname: value, };
            }else if(name=== "FirstName"){
                return{
                    ...preValue,
                    fname: value, };
            }else if(name=== "Email"){
                return{
                    ...preValue,
                    email: value, };
            }else {
                return{
                    ...preValue,
                };
            }
        })
        
    }

    function processSignIn(e) {
        e.preventDefault();
        var usrPass = registerInfo.password;
        var usrLname = registerInfo.lname;
        var usrFname = registerInfo.fname;
        var usrEmail = registerInfo.email;
        var usrAdmin = registerInfo.adm;
        axios
        .post("/SignIn",{em: usrEmail, pass:usrPass, ln:usrLname, fn: usrFname, ad:usrAdmin})
        .then((res)=>{
            var data = res.data;
            if(!data.hasOwnProperty("error")){
                console.log("succes register");
                registerInfo.regis = data.Registered
                props.handler(registerInfo.regis);
            }else{
                setErrorMSG(data.message);
            }
        })
        .catch((err)=>{
            console.log(errorMSG);
        });
       }
    return(
        <div>
        <div className="overlay"></div>
            <video src={BG} autoPlay loop muted/>
        <form className="logged">
            <br/>
            <input
            name="FirstName" 
            type="text" 
            placeholder="First Name" 
            onChange={handleUpdate}
            />
            <br/>
            <input
            name="LastName" 
            type="text" 
            placeholder="Last Name" 
            onChange={handleUpdate}
            />
            <br/>
            <input
            name="Email" 
            type="email" 
            placeholder="email_data@email.com" 
            onChange={handleUpdate}
            />
            <br/>
            <input 
            name="Password" 
            type="password" 
            placeholder="Password"
            onChange={handleUpdate}
            />
            <br/>
            <button 
            type="submit" 
            onClick={processSignIn}>
                Create Account
            </button>
        </form>
        </div>
    )
}

export default (SignIn)
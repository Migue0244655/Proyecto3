import React from "react";
import { useState } from "react";
import 'regenerator-runtime/runtime';
import axios from 'axios';
import BG from "../videos/back.mp4"

function Login(props){
    var[registerInfo, setRegisterInfo] =useState({
        usrEmail: "", 
        password: "",
        fname: "",
        lname: "",
    })
    var[errorMSG, setErrorMSG]= useState("INCORRECT DATA");

    function handleUpdate(e) {
        const {value, name} = e.target;
        setRegisterInfo((preValue) =>{
            if(name=== "Email"){
                return{
                    ...preValue,
                    usrEmail: value, 

                };
            } else {
                return{
                    ...preValue,
                    password: value,
                };
            }
        })
        
    }

    function processLogin(e) {
        e.preventDefault();
        var usrEmail = registerInfo.usrEmail;
        var usrPass = registerInfo.password;
        axios
        .post("/login",{email: usrEmail, pass:usrPass})
        .then((res)=>{
            var data = res.data;
            if(!data.hasOwnProperty("error")){
                console.log("succes log in");
                registerInfo.fname= data.fname;
                registerInfo.lname= data.lname;
                props.handler(registerInfo);
            }else{
                setErrorMSG(data.message);
            }
        })
        .catch((err)=>{
            console.log(errorMSG);
        });
       }
    return(
        <div>
        <div className="overlay"></div>
            <video src={BG} autoPlay loop muted/>
        <form className="logged">
            <input
            name="Email" 
            type="email" 
            placeholder="Email" 
            onChange={handleUpdate}
            />
            <br/>
            <input 
            name="Password" 
            type="password" 
            placeholder="Password"
            onChange={handleUpdate}
            />
            <br/>
            <button 
            type="submit" 
            onClick={processLogin}>
                Log In
            </button>
        </form>
        </div>
    )
}

export default (Login)
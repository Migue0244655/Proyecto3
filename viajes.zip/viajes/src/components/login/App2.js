import React, {useState} from 'react';
import Login from './login';
import Main from '../main';
import HeaderLog from '../headerLog';
import SignIn from './singin';


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


 
function App2() {
  var [isLoggedIn, setIsLoggedIn] = useState(false);
  var [isRegisterIn, setIsRegisterIn] = useState(false);
  var [accountInfo, setAccountInfo] = useState();
  var [userName, setUserName]= useState({});

  function logUser(userName) {
    setUserName(userName)
    setIsLoggedIn(true);
  }

  function registerUser(accountInfo) {
    setAccountInfo(accountInfo)
    setIsRegisterIn(true);
  }
  
  function renderAcc() {
    return(
      <div>

      </div>
    );
  }

  function logOutUser() {
    setIsLoggedIn(false);
  }
  

  function renderConditional(){
    console.log("Hello " + userName )
    return(
      <div>
            <HeaderLog/>
            <Main/>
            <button className='logout' onClick={logOutUser}>Log Out</button>
            <button onClick={logOutUser}>Account</button>
      </div>
    );
  }

  function renderLogConditional(){
    return( 
      <div>
        { isLoggedIn ? renderConditional() : 
        <Login handler={logUser}/>}
        </div>
      );
  }

  return( 
  <div>
    { isRegisterIn ? renderLogConditional() : 
    <SignIn handler={registerUser}/>}
    </div>
  )
}

export default App2;
export {}
import React, { useState } from "react";
import BG from "./videos/back.mp4"
import 'bootstrap/dist/css/bootstrap.min.css';
import Search from "./busqueda";
import ListaVuelos from "./vuelos";



const Main = () =>{

  
    var [isAvailable, setIsAvailable] = useState(false);
    // var [flightsList, setFlightsList] = useState([]);
    var [flightsList, setFlightsList] = useState([]);

    function lookUp(flightsList) {
      if(typeof flightsList !== "undefined" || flightsList.length > 0){
        setIsAvailable(true);
        setFlightsList(flightsList);
        }
    }
    return(
        <div>
            <div className="overlay"></div>
            <video src={BG} autoPlay loop muted/>
            { isAvailable ? <ListaVuelos flights={flightsList}/> : 
          <Search handler={lookUp}/>}
        </div>
    );
}

export default Main
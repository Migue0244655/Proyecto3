import ListGroup from 'react-bootstrap/ListGroup';
import Button from 'react-bootstrap/Button';
// import { useEffect, useState } from 'react';
// import axios from 'axios';
import React, { useState } from 'react';

var comprados = [];

function Comprar(vuelo){
    comprados.push(vuelo);
    console.log(comprados);
};

function ListaVuelos(props) {
    var[itemsInfo, setItemsInfo] =useState(props.flights);

    function createList_Item(item) {
        return (
            <ListGroup horizontal>
                <ListGroup.Item>Aeropuerto salida: {item.iataB} -- Terminal: {item.termB} <br></br>
                                Aeropuerto llegada: {item.iataA}  -- Terminal: {item.termA}</ListGroup.Item>
                <ListGroup.Item>Num. Vuelo: {item.num}</ListGroup.Item>
                <ListGroup.Item>Origen: {item.ori} <br></br>Destino: {item.des}</ListGroup.Item>
                <ListGroup.Item>Ida: {item.dep} <br></br>Llegada: {item.arr} </ListGroup.Item>
                <ListGroup.Item>precio: € {item.price} EUR</ListGroup.Item>
                <Button variant="success" onClick={()=>Comprar({item})}>Comprar</Button>
            </ListGroup>
        )
    }
    return(
        <div className="content6">
            {itemsInfo.map(createList_Item)}
            <br/>
        </div>
    );
}

export default ListaVuelos
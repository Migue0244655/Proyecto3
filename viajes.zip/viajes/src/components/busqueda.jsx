import React from "react";
import { useState } from "react";
import 'regenerator-runtime/runtime';
import axios from 'axios';



function cabeza() {
    return(
        <div className="content">
                <h1>V O L F L Y</h1>
                <p>new agency for new travelers</p>
            </div>
    );
}



function Search(props){
    var[registerInfo, setRegisterInfo] =useState({
        originCity:"",
        destinationCity:"",
        travPeople:"",
        price:[],
        dep: [],
        arr: [],
        num: [],
        iataA: [],
        termA:[],
        iataB: [],
        termB: [],
 
    })
    var[errorMSG, setErrorMSG]= useState("NO JALO");

    //corregir l el handdler
    function handleUpdate(e) {
        const {value, name} = e.target;
        setRegisterInfo((preValue) =>{
            if(name=== "Origin"){
                return{
                    ...preValue,
                    originCity: value, 
                    
                };
            } else if(name==="Destination") {
                return{
                    ...preValue, 
                    destinationCity: value,
                };
            } else if(name==="fechaI") {
                return{
                    ...preValue,
                    dep: value,
                };
            }else if(name==="peopleS"){
                return{
                    ...preValue,
                    travPeople: value
                };
            }else{
                return{
                    ...preValue,
                }
            }
            
        })
        
    }
    
    function proccessFlights(e) {

        e.preventDefault();
        
        var originCity = registerInfo.originCity;
        var destinationCity = registerInfo.destinationCity;
        var dep = registerInfo.dep;
        var travPeople = registerInfo.travPeople;
        var reqData = {origin: originCity, destino:destinationCity, date: dep, people: travPeople};
        console.log(reqData);
        axios
        .post("/vuelos",{origin: originCity, destino:destinationCity, date: dep, people: travPeople})
        .then((res)=>{
            var data = res.data;
            console.log(data);
            if(!data.hasOwnProperty("error") && data!=="ClientError"){
                console.log("succes");
                // console.log(data.length);
                // console.log(data);
                // registerInfo[0].dep=data[0].num;
                // console.log(registerInfo[0].dep);
                // for (let index = 0; index < data.length; index++) {
                //     console.log(index);
                //     // registerInfo.dep[index]= data[index].dep;
                //     // registerInfo.arr[index]= data[index].arr;
                //     // registerInfo.num[index]= data[index].num;
                //     // registerInfo.iataA[index]= data[index].iataA;
                //     // registerInfo.termA[index]= data[index].termA;
                //     // registerInfo.iataB[index]= data[index].iataB;
                //     // registerInfo.termB[index]= data[index].termB;
                //     // //si se pasa la info pero no puede mostarmela lisa entera por cada uno ya que son arrelo de arreglos
                //     // // registerInfo.originCity= data.originCity;
                //     // // registerInfo.destinationCity= data.destinationCity;
                //     // // registerInfo.dep= data.dep;
                //     // // registerInfo.travPeople= data.travPeople;
                //     // console.log("datos de vuelos "+ index +": " + registerInfo[index].num );
                    
                // }
                props.handler(data, registerInfo);

            }else{
                alert("Wrong Data or Incomplete Fields or No flights available")
                setErrorMSG(data.message);
            }
        })
        .catch((err)=>{
            console.log(errorMSG);
        });
    }

    return(
        
        <form>
            {cabeza()}
            <div className="content2">
                <input className="ipts" type="search" placeholder="Origin" name="Origin"  onChange={handleUpdate} required/>
            </div>
            <div className="content3">
                <input className="ipts" type="search" placeholder="Destination" onChange={handleUpdate} name="Destination"required/>
            </div>
            <div className="content7">
                <input className="peop" type="number" placeholder="# Passengers" onChange={handleUpdate} name="peopleS" required/>
            </div>
            <div>
                <label className="content4"><input className="calend" type="date" name="fechaI" onChange={handleUpdate}required/>
                </label>
                <label className="content5"><input  className="calend"  type="date" name="fechaF"  onChange={handleUpdate} required/>
                </label>
                <button className="vuelos" type="submit" onClick={proccessFlights} >check out flights</button>	
            </div>
            </form>
        
    )
}





export default Search;


import Header from './components/header';
import React from 'react';
import App2 from './components/login/App2';
// import Selection from './components/seleccion';

function App() {



  return (
    <div>
       <Header/>
       <App2/>
    </div>
  );
}

export default App;

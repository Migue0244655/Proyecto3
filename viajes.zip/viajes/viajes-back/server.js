const express = require("express");
const app = express();
var Amadeus = require('amadeus');

const mongoose = require("mongoose"); 
app.use(express.json());
app.use(express.urlencoded({extended:true}));

mongoose.connect('mongodb://localhost:27017/VolflyUsers', {useNewUrlParser: true, useUnifiedTopology: true});



var amadeus = new Amadeus({
    clientId: '6gKKh3u6qCUNo7WyAMGAzILzOXTLweKk',
    clientSecret: 'ecRguUMK0yzi950b'
});

var cityCache = [];
var p_date;
var p_people;
var code1;
var code2;

function searchCityCode(cityName){
    var tmpCity = cityCache.filter((item) =>{
        return item.city === cityName;
    });
    if(!tmpCity.length){
        return amadeus.referenceData.locations.get({
            keyword: cityName,
            subType: 'AIRPORT,CITY'
        }).then((response)=>{
            var jsonData = response.data;
            tmpCity = {
                city: cityName,
                code:jsonData[0]["iataCode"]
            };
            cityCache.push(tmpCity)
            return tmpCity.code;
        }).catch(function(responseError){
            console.log(responseError.code);
        });
    }else{
        return tmpCity[0].code;
    }
}


function crearRegreso(vuelos, cO, cD){
    var vuelos_temp = vuelos.map(element => {
        var final = element["itineraries"][0]["segments"].length;
        var obj = {
            ori: cO,
            des: cD,
            price: element["price"]["grandTotal"],
            dep: element["itineraries"][0]["segments"][0]["departure"]["at"],
            arr: element["itineraries"][0]["segments"][final-1]["arrival"]["at"],
            num: element["itineraries"][0]["segments"][0]["number"],
            iataA: element["itineraries"][0]["segments"][final-1]["arrival"]["iataCode"],
            termA: element["itineraries"][0]["segments"][final-1]["arrival"]["terminal"],
            iataB: element["itineraries"][0]["segments"][0]["departure"]["iataCode"],
            termB: element["itineraries"][0]["segments"][0]["departure"]["terminal"]
        }
        return (
            obj
        )
    });
    return vuelos_temp;
    
}

app.post("/vuelos", async (req, res) =>{
    p_date = req.body.date;
    p_people = req.body.people;
    code1 = await searchCityCode(req.body.origin.toUpperCase());
    code2 = await searchCityCode(req.body.destino.toUpperCase());
    var flights = await amadeus.shopping.flightOffersSearch.get({
        originLocationCode: code1,
        destinationLocationCode: code2,
        departureDate: p_date,
        adults: p_people
    }).then(function(response){
        var resultFlights = crearRegreso(response.data,code1,code2);
        return(resultFlights);
    }).catch(function(responseError){
        console.log(responseError.code);
        return(responseError.code);
    })
    console.log(flights);
    res.json(flights)
    // console.log(informativo);
    // res.json(informativo);
});

//-------------------MONGO DB ________________________





app.get("/", async (req,res) =>{
    
    //para pruebas
    /*
    var y = await searchCityCode("London");
    var t = await searchCityCode("Guadalajara");
*/
    /*como se lo tienes que dar
    departureDate: '2022-12-12',
    adults: '2'
    */

    
    //Para ver si el problema es la informacion que le llega(con esto si funciona)
   /*
    code1 = "LON";
    code2 = "GDL";
    p_date = '2022-12-12';
    p_people = "2";
    */

    //Para ver si funciona con la info las funciones

    
    p_date = '2022-12-12';
    p_people = "2";
    code1 = await searchCityCode("Guadalajara");
    code2 = await searchCityCode("London");
    

    var x = await amadeus.shopping.flightOffersSearch.get({
        originLocationCode: code1,
        destinationLocationCode: code2,
        departureDate: p_date,
        adults: p_people
    }).then(function(response){
        var resultFlights = crearRegreso(response.data);
        return(resultFlights);
    }).catch(function(responseError){
        console.log(responseError.code);
        return(responseError.code);
    })

    res.send(x);
});


//-----------------------------------------------------
//LOGIN and Sign In

const userSignIn=new mongoose.Schema({
    fname: String,
    lname: String,
    Username: String,
    Password: String,
    Email: String,
    Admin: Boolean,
    Registered: Boolean,
});

const UserInfo = mongoose.model("UserInfo", userSignIn); 


app.post("/signIn", (req, res) =>{
    
    const p_password = req.body.pass;
    const p_lastname = req.body.ln;
    const p_firstname = req.body.fn;
    const p_email = req.body.em;
    const p_admin = req.body.ad;

    console.log(req.body);

    UserInfo.find ({ Email: { $eq: p_email }}, 
                    (err) => { if(err) {
                         res.json({error: "Ya esta registardo"})
                        } else {
                            var NewUser= new UserInfo({
                                fname: p_firstname,
                                lname: p_lastname,
                                Password: p_password,
                                Email: p_email,
                                Admin: p_admin,
                                Registered: true,
                            })
                            NewUser.save()
                            console.log(NewUser);
                            res.json(NewUser)
                        } } );
    
    })


app.post("/login", (req, res) =>{
    const p_userEmail = req.body.email;
    const p_password = req.body.pass;


    UserInfo.find ({ Email: p_userEmail }, (err,UserInfo) => { if(err) {
             console.log("no esta");
            } else {
                if (UserInfo[0].Password===p_password) {
                    var nomb=[]
                    nomb=UserInfo[0]
                    console.log(nomb);
                    res.json(nomb[0])
               }else{console.log("no se puedes tas mal");}
            } } );

})




app.listen(5010,(err) =>{
    console.log("Listening on 5010");
    var admin= new UserInfo({
        fname: "AdminMaster",
        lname: "Masteradmin",
        Password: "admin1234",
        Email: "admin@admin.com",
        Admin: true,
        Registered: true,
    })
    admin.save()
}); 